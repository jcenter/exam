class exam7 {
    
}
