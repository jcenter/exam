public interface Filter {
  void setFilter(String fltr);
  boolean applyFilter(String value);
}
